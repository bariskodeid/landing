/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./build/*.html"],
  theme: {
    color: {
      transparent: 'transparent',
      current: 'currentColor',
    },
    extend: {
      
    },
    fontFamily: {
      sans: ['Genty', 'sans-serif'],
    },
  },
  plugins: [],
}

